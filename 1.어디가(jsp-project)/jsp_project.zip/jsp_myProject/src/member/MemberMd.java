package member;

public class MemberMd {
	
	private String user_id;
	private String user_pw;
	private String user_nName;
	private String user_name;
	private String user_num1;
	private String user_num2;
	private String user_num3;
	private String user_birthday;
	private int user_loc1;
	private int user_loc2;
	
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_pw() {
		return user_pw;
	}
	public void setUser_pw(String user_pw) {
		this.user_pw = user_pw;
	}
	public String getUser_nName() {
		return user_nName;
	}
	public void setUser_nName(String user_nName) {
		this.user_nName = user_nName;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_num1() {
		return user_num1;
	}
	public void setUser_num1(String user_num1) {
		this.user_num1 = user_num1;
	}
	public String getUser_num2() {
		return user_num2;
	}
	public void setUser_num2(String user_num2) {
		this.user_num2 = user_num2;
	}
	public String getUser_num3() {
		return user_num3;
	}
	public void setUser_num3(String user_num3) {
		this.user_num3 = user_num3;
	}
	public String getUser_birthday() {
		return user_birthday;
	}
	public void setUser_birthday(String user_birthday) {
		this.user_birthday = user_birthday;
	}
	public int getUser_loc1() {
		return user_loc1;
	}
	public void setUser_loc1(int user_loc1) {
		this.user_loc1 = user_loc1;
	}
	public int getUser_loc2() {
		return user_loc2;
	}
	public void setUser_loc2(int user_loc2) {
		this.user_loc2 = user_loc2;
	}
	
}
